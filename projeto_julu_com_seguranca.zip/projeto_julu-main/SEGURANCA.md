# Segurança — Projeto Julu

## Alterações aplicadas
- Tráfego HTTP sem criptografia bloqueado no Android; conexões devem usar HTTPS.
- Backup Android desativado (mantido) para reduzir exposição de dados locais.
- Minificação e redução de recursos ativadas na build de release.
- Mensagens de falha no cadastro não exibem detalhes internos do Firebase.
- Regras iniciais do Firestore limitam cada usuário autenticado ao próprio documento `usuarios/{uid}` e aos campos de perfil previstos.

## Ação obrigatória no Firebase
O arquivo `firestore.rules` **não é aplicado automaticamente** ao projeto Firebase.
Publique-o no Firebase Console > Firestore Database > Regras (ou via Firebase CLI) antes de disponibilizar o aplicativo. Confira as regras em ambiente de teste.

## Limitações que ainda precisam ser resolvidas antes de produção
- O carrinho e a confirmação de pedido ainda são locais; o aplicativo não grava pedidos de forma segura no servidor.
- A tela de pagamento apenas registra uma confirmação local e informa que o pagamento será combinado com a loja. Não processa pagamentos.
- Não há validação de preço no servidor. Nunca confie em preços enviados pelo aplicativo para cobrança.
- O arquivo `google-services.json` contém identificadores de configuração do Firebase. Eles não são, por si só, senhas; a segurança real depende das regras do Firebase e das restrições/configurações do projeto.
- Configure políticas de autenticação, proteção contra abuso e monitoramento no Firebase Console.

## Antes de publicar
1. Publique e teste `firestore.rules`.
2. Teste cadastro, login, recuperação de senha e leitura do próprio perfil.
3. Implemente pedidos e preços validados no backend antes de aceitar pagamentos reais.
4. Gere e teste uma versão `release` assinada.
